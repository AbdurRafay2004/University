#include<stdio.h>

int main()
{
    printf("Sum = %d", 54+56);

    return 0;
}